package DataKaryawanPanel;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class DataKaryawanPanel extends JPanel {
    private JTable table;
    private DefaultTableModel tableModel;
    private JTextField tfSearch, tfNama, tfGajiHarian;
    private JComboBox<String> cbJabatan;
    private JButton btnEdit, btnSearch;
    private JLabel lblTotalPengeluaran;

    public DataKaryawanPanel() {
        setLayout(new BorderLayout());
        setBackground(Color.WHITE);

        // Panel untuk Search dan Form
        JPanel panelAtas = new JPanel();
        panelAtas.setLayout(new GridBagLayout());
        panelAtas.setBackground(new Color(240, 240, 240));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(5, 5, 5, 5);

        // Search Karyawan
        gbc.gridx = 0;
        gbc.gridy = 0;
        panelAtas.add(new JLabel("Search Karyawan:"), gbc);
        
        tfSearch = new JTextField();
        gbc.gridx = 1;
        panelAtas.add(tfSearch, gbc);
        
        btnSearch = new JButton("Search");
        gbc.gridx = 2;
        panelAtas.add(btnSearch, gbc);

        // Nama
        gbc.gridx = 0;
        gbc.gridy = 1;
        panelAtas.add(new JLabel("Nama:"), gbc);

        tfNama = new JTextField();
        gbc.gridx = 1;
        panelAtas.add(tfNama, gbc);

        // Jabatan
        gbc.gridx = 0;
        gbc.gridy = 2;
        panelAtas.add(new JLabel("Jabatan:"), gbc);

        cbJabatan = new JComboBox<>(new String[]{"Pengoperasian Penggilingan", "Pemotong Ikan", "Penakar Sagu", "Peracik Bumbu"});
        gbc.gridx = 1;
        panelAtas.add(cbJabatan, gbc);

        // Gaji Perhari
        gbc.gridx = 0;
        gbc.gridy = 3;
        panelAtas.add(new JLabel("Gaji Perhari:"), gbc);

        tfGajiHarian = new JTextField();
        gbc.gridx = 1;
        panelAtas.add(tfGajiHarian, gbc);

        // Edit Button
        btnEdit = new JButton("Edit");
        gbc.gridx = 2;
        panelAtas.add(btnEdit, gbc);

        add(panelAtas, BorderLayout.NORTH);

        // Tabel Data Karyawan
        String[] kolom = {"Nama", "Jabatan", "Gaji Harian", "Kehadiran", "Gaji Bulanan"};
        Object[][] data = {
            {"Andi", "Pengoperasian Penggilingan", 170000, 22, 3740000.0},
            {"Budi", "Pemotong Ikan", 170000, 20, 3400000.0},
            {"Citra", "Penakar Sagu", 170000, 22, 3740000.0},
            {"Dian", "Peracik Bumbu", 170000, 21, 3570000.0},
            {"Eka", "Pengoperasian Penggilingan", 170000, 20, 3400000.0},
            {"Faris", "Pemotong Ikan", 170000, 23, 3910000.0},
            {"Gina", "Penakar Sagu", 170000, 22, 3740000.0}
        };

        tableModel = new DefaultTableModel(data, kolom);
        table = new JTable(tableModel);
        table.setRowHeight(25);
        table.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        table.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 14));
        table.getTableHeader().setBackground(new Color(230, 230, 230));
        table.setGridColor(Color.LIGHT_GRAY);

        JScrollPane scrollPane = new JScrollPane(table);
        add(scrollPane, BorderLayout.CENTER);

        // Akumulasi Pengeluaran Bulanan
        lblTotalPengeluaran = new JLabel("Total Pengeluaran Bulanan: Rp0");
        lblTotalPengeluaran.setFont(new Font("Segoe UI", Font.BOLD, 14));
        lblTotalPengeluaran.setForeground(new Color(178, 34, 34));
        add(lblTotalPengeluaran, BorderLayout.SOUTH);

        // Edit button action
        btnEdit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int selectedRow = table.getSelectedRow();
                if (selectedRow != -1) {
                    // Update data karyawan
                    String nama = tfNama.getText();
                    String jabatan = (String) cbJabatan.getSelectedItem();
                    String gajiHarianText = tfGajiHarian.getText();
                    if (!nama.isEmpty() && !gajiHarianText.isEmpty()) {
                        try {
                            // Pastikan gaji harian diubah ke tipe Double
                            double gajiHarian = Double.parseDouble(gajiHarianText);
                            tableModel.setValueAt(nama, selectedRow, 0);
                            tableModel.setValueAt(jabatan, selectedRow, 1);
                            tableModel.setValueAt(gajiHarian, selectedRow, 2);
                            updateKehadiran(selectedRow);  // Update kehadiran otomatis
                            updateGajiBulanan(selectedRow, gajiHarian);
                        } catch (NumberFormatException ex) {
                            JOptionPane.showMessageDialog(DataKaryawanPanel.this, "Gaji Harian harus berupa angka", "Error", JOptionPane.ERROR_MESSAGE);
                        }
                    } else {
                        JOptionPane.showMessageDialog(DataKaryawanPanel.this, "Nama atau Gaji Harian tidak boleh kosong", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                }
            }
        });

        // Search button action
        btnSearch.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String searchTerm = tfSearch.getText().toLowerCase();
                for (int i = 0; i < tableModel.getRowCount(); i++) {
                    String namaKaryawan = tableModel.getValueAt(i, 0).toString().toLowerCase();
                    if (namaKaryawan.contains(searchTerm)) {
                        table.setRowSelectionInterval(i, i);
                        break;
                    }
                }
            }
        });

        // Update Gaji Bulanan secara otomatis
        for (int i = 0; i < tableModel.getRowCount(); i++) {
            double gajiHarian = 0;
            Object gajiHarianObj = tableModel.getValueAt(i, 2);
            if (gajiHarianObj instanceof Integer) {
                gajiHarian = ((Integer) gajiHarianObj).doubleValue();
            } else if (gajiHarianObj instanceof Double) {
                gajiHarian = (Double) gajiHarianObj;
            }
            updateGajiBulanan(i, gajiHarian);
            updateKehadiran(i); // Mengupdate kehadiran secara otomatis
        }
    }

    private void updateKehadiran(int row) {
        // Menghitung kehadiran berdasarkan karyawan
        // Misalnya, asumsi kehadiran dihitung otomatis berdasarkan jumlah hari kerja dalam sebulan
        // Di sini, kita bisa menggunakan logika kehadiran berdasarkan jabatan atau lainnya
        int hariKerja = 30;  // Misalnya, kita anggap ada 30 hari dalam sebulan
        int kehadiran = (int) tableModel.getValueAt(row, 3);

        // Bisa ditambahkan logika lebih lanjut untuk mengatur kehadiran
        // Misalnya, berdasarkan kondisi jabatan atau waktu libur
        // Update otomatis kehadiran berdasarkan perhitungan tertentu
        tableModel.setValueAt(hariKerja, row, 3);  // Contoh, set kehadiran berdasarkan hari kerja
    }

    private void updateGajiBulanan(int row, double gajiHarian) {
        int kehadiran = (int) tableModel.getValueAt(row, 3);

        // Hitung gaji bulanan
        double gajiBulanan = gajiHarian * kehadiran;
        tableModel.setValueAt(gajiBulanan, row, 4);
        updateTotalPengeluaran();
    }

    private void updateTotalPengeluaran() {
        double totalPengeluaran = 0;
        for (int i = 0; i < tableModel.getRowCount(); i++) {
            Object gajiBulananObj = tableModel.getValueAt(i, 4);
            double gajiBulanan = 0;
            if (gajiBulananObj instanceof Integer) {
                gajiBulanan = ((Integer) gajiBulananObj).doubleValue();
            } else if (gajiBulananObj instanceof Double) {
                gajiBulanan = (Double) gajiBulananObj;
            }
            totalPengeluaran += gajiBulanan;
        }
        lblTotalPengeluaran.setText("Total Pengeluaran Bulanan: Rp" + String.format("%,.0f", totalPengeluaran));
    }
}
