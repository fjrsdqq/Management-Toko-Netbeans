package DataSupplierPanel;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

public class DataSupplierPanel extends JPanel {
    public DataSupplierPanel() {
        setLayout(new BorderLayout());
        setBackground(Color.WHITE);

        String[] kolom = {"ID Supplier", "Alamat", "No. Telepon", "Email", "Sagu (kg)", "Ikan (kg)"};
        Object[][] data = {
            {"SUP001", "Jl. Mawar No. 12", "08123456789", "supplier1@email.com", 50, 30},
            {"SUP002", "Jl. Melati No. 5", "08234567891", "supplier2@email.com", 100, 70},
            {"SUP003", "Jl. Kenanga No. 8", "08345678912", "supplier3@email.com", 30, 20},
        };

        JTable table = new JTable(new DefaultTableModel(data, kolom));
        table.setRowHeight(25);
        table.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        table.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 14));
        table.setGridColor(new Color(220, 220, 220));
        table.setShowGrid(true);

        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        add(scrollPane, BorderLayout.CENTER);

        JLabel title = new JLabel("Data Supplier", SwingConstants.CENTER);
        title.setFont(new Font("Segoe UI", Font.BOLD, 20));
        title.setBorder(BorderFactory.createEmptyBorder(10, 0, 10, 0));
        add(title, BorderLayout.NORTH);
    }
}
