package Main;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import DataSupplierPanel.DataSupplierPanel;
import DataKaryawanPanel.DataKaryawanPanel;

class DataBarangPanel extends JPanel {
    private JTable tabelBarang;
    private DefaultTableModel tableModel;
    private JComboBox<String> comboJenisBarang;

    public DataBarangPanel() {
        setLayout(new BorderLayout());
        setBackground(new Color(250, 250, 250));

        JPanel panelAtas = new JPanel(new FlowLayout(FlowLayout.LEFT));
        panelAtas.setBackground(new Color(250, 250, 250));

        panelAtas.add(new JLabel("Jenis Bahan:"));
        comboJenisBarang = new JComboBox<>(new String[]{"Jenis Ikan", "Sagu", "Bumbu - Bumbu"});
        panelAtas.add(comboJenisBarang);

        JButton btnTambah = new JButton("Tambah");
        JButton btnHapus = new JButton("Hapus");
        JButton btnEdit = new JButton("Edit");

        panelAtas.add(btnTambah);
        panelAtas.add(btnHapus);
        panelAtas.add(btnEdit);

        add(panelAtas, BorderLayout.NORTH);

        String[] kolom = {"Jenis Bahan", "Nama Barang", "Jumlah Stok", "Keterangan"};
        Object[][] data = {
            {"Jenis Ikan", "Ikan Tenggiri", 50, "Untuk adonan utama"},
            {"Sagu", "Sagu Tani", 20, "Pengental adonan"},
            {"Bumbu - Bumbu", "Bawang Putih", 15, "Untuk rasa"},
        };

        tableModel = new DefaultTableModel(data, kolom);
        tabelBarang = new JTable(tableModel);
        tabelBarang.setRowHeight(25);
        tabelBarang.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        tabelBarang.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 14));
        tabelBarang.getTableHeader().setBackground(new Color(230, 230, 230));
        tabelBarang.setGridColor(Color.LIGHT_GRAY);

        JScrollPane scrollPane = new JScrollPane(tabelBarang);
        scrollPane.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        add(scrollPane, BorderLayout.CENTER);

        btnTambah.addActionListener(e -> {
            String jenis = (String) comboJenisBarang.getSelectedItem();
            tableModel.addRow(new Object[]{jenis, "Nama Barang", 0, "Keterangan"});
        });

        btnHapus.addActionListener(e -> {
            int selectedRow = tabelBarang.getSelectedRow();
            if (selectedRow != -1) {
                tableModel.removeRow(selectedRow);
            }
        });

        btnEdit.addActionListener(e -> {
            int row = tabelBarang.getSelectedRow();
            if (row != -1) {
                tabelBarang.editCellAt(row, 1);
            }
        });
    }
}

class RoundedPanel extends JPanel {
    private int cornerRadius = 20;

    public RoundedPanel(LayoutManager layout, int radius) {
        super(layout);
        this.cornerRadius = radius;
        setOpaque(false);
    }

    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Dimension arcs = new Dimension(cornerRadius, cornerRadius);
        int width = getWidth();
        int height = getHeight();
        Graphics2D graphics = (Graphics2D) g;
        graphics.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        graphics.setColor(new Color(40, 40, 40));
        graphics.fillRoundRect(0, 0, width - 1, height - 1, arcs.width, arcs.height);

        graphics.setColor(new Color(0, 0, 0, 30));
        graphics.drawRoundRect(0, 0, width - 1, height - 1, arcs.width, arcs.height);
    }
}

public class DashboardSiomay extends JFrame {

    JPanel sidebar, contentPanel;
    CardLayout cardLayout;

    Color sidebarColor = new Color(30, 30, 30);
    Color menuColor = new Color(50, 50, 50);
    Color selectedColor = new Color(70, 130, 180);
    Color textColor = Color.WHITE;

    public DashboardSiomay() {
        setTitle("Dashboard Pabrik Siomay Pak Min");
        setSize(1100, 650);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        sidebar = new RoundedPanel(new GridLayout(7, 1, 0, 5), 30);
        sidebar.setPreferredSize(new Dimension(200, 650));
        sidebar.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        sidebar.setBackground(sidebarColor);

        String[] menuItems = {
            "Dashboard", "Data Barang", "Data Supplier",
            "Data Karyawan", "Data Pelanggan", "Keuangan", "Logout"
        };

        cardLayout = new CardLayout();
        contentPanel = new JPanel(cardLayout);

        for (String item : menuItems) {
            JButton btn = new JButton(item);
            btn.setFocusPainted(false);
            btn.setBackground(menuColor);
            btn.setForeground(textColor);
            btn.setFont(new Font("Segoe UI", Font.PLAIN, 14));
            btn.setBorderPainted(false);
            btn.setHorizontalAlignment(SwingConstants.LEFT);
            btn.setCursor(new Cursor(Cursor.HAND_CURSOR));

            btn.addMouseListener(new java.awt.event.MouseAdapter() {
                public void mouseEntered(java.awt.event.MouseEvent evt) {
                    btn.setBackground(selectedColor.darker());
                }
                public void mouseExited(java.awt.event.MouseEvent evt) {
                    btn.setBackground(menuColor);
                }
            });

            sidebar.add(btn);

            if (item.equals("Dashboard")) {
                contentPanel.add(createDashboardPanel(), item);
            } else if (item.equals("Data Barang")) {
                contentPanel.add(new DataBarangPanel(), item);
            } else if (item.equals("Data Supplier")) {
                contentPanel.add(new DataSupplierPanel(), item);
            } else if (item.equals("Data Karyawan")) {
                contentPanel.add(new DataKaryawanPanel(), item);
            }
                else {
                JPanel panel = new JPanel(new BorderLayout());
                panel.setBackground(Color.WHITE);
                panel.add(new JLabel("Halaman " + item, SwingConstants.CENTER), BorderLayout.CENTER);
                contentPanel.add(panel, item);
            }

            btn.addActionListener(e -> cardLayout.show(contentPanel, item));
        }

        add(sidebar, BorderLayout.WEST);
        add(contentPanel, BorderLayout.CENTER);
    }

    private JPanel createDashboardPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(new Color(245, 245, 245));

        JPanel topPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        topPanel.setBackground(new Color(245, 245, 245));
        topPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        topPanel.add(new JLabel("Tanggal:"));
        JTextField tfTanggal = new JTextField(10);
        topPanel.add(tfTanggal);

        topPanel.add(new JLabel("Nama Pelanggan:"));
        JTextField tfPelanggan = new JTextField(10);
        topPanel.add(tfPelanggan);

        JButton btnCari = new JButton("Cari");
        btnCari.setBackground(selectedColor);
        btnCari.setForeground(Color.WHITE);
        btnCari.setFocusPainted(false);
        topPanel.add(btnCari);

        panel.add(topPanel, BorderLayout.NORTH);

        String[] kolom = {"Tanggal", "Nama Pelanggan", "Jumlah Pembelian", "Total Pemasukan", "Pengeluaran"};
        Object[][] data = {
            {"2025-04-21", "Andi", 10, 150000, 30000},
            {"2025-04-21", "Budi", 5, 75000, 15000},
            {"2025-04-22", "Citra", 7, 105000, 20000},
            {"2025-04-23", "Dian", 12, 180000, 40000}
        };

        JTable table = new JTable(new DefaultTableModel(data, kolom));
        table.setRowHeight(25);
        table.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        table.setGridColor(new Color(220, 220, 220));
        table.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 14));
        table.getTableHeader().setBackground(new Color(230, 230, 230));
        table.setShowGrid(true);
        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        panel.add(scrollPane, BorderLayout.CENTER);

        JPanel bottomPanel = new JPanel(new GridLayout(1, 2));
        bottomPanel.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
        bottomPanel.setBackground(new Color(245, 245, 245));

        JLabel lblPendapatan = new JLabel("Total Pendapatan Hari Ini: Rp405.000");
        JLabel lblPengeluaran = new JLabel("Total Pengeluaran Hari Ini: Rp105.000");

        lblPendapatan.setFont(new Font("Segoe UI", Font.BOLD, 16));
        lblPengeluaran.setFont(new Font("Segoe UI", Font.BOLD, 16));
        lblPendapatan.setForeground(new Color(34, 139, 34));
        lblPengeluaran.setForeground(new Color(178, 34, 34));

        bottomPanel.add(lblPendapatan);
        bottomPanel.add(lblPengeluaran);
        panel.add(bottomPanel, BorderLayout.SOUTH);

        return panel;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new DashboardSiomay().setVisible(true));
    }
}