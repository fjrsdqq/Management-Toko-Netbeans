package Management;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

public class DataBarangPanel extends JPanel {

    public DataBarangPanel() {
        setLayout(new BorderLayout());
        setBackground(Color.WHITE);

        // Panel Atas
        JPanel inputPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        inputPanel.setBackground(Color.WHITE);

        JComboBox<String> cbBarang = new JComboBox<>(new String[]{"Siomay Ikan", "Siomay Ayam", "Kulit Tahu", "Tahu", "Telur"});
        JTextField tfJumlah = new JTextField(10);  // Inisialisasi tfJumlah
        JButton btnTambah = new JButton("Tambah");
        JButton btnEdit = new JButton("Edit");
        JButton btnHapus = new JButton("Hapus");

        inputPanel.add(new JLabel("Barang:"));
        inputPanel.add(cbBarang);
        inputPanel.add(new JLabel("Jumlah:"));
        inputPanel.add(tfJumlah);
        inputPanel.add(btnTambah);
        inputPanel.add(btnEdit);
        inputPanel.add(btnHapus);

        add(inputPanel, BorderLayout.NORTH);

        // Tabel
        String[] kolom = {"Nama Barang", "Stok Masuk", "Stok Keluar", "Sisa Stok"};
        Object[][] data = {
            {"Siomay Ikan", 100, 50, 50},
            {"Siomay Ayam", 200, 120, 80}
        };
        JTable table = new JTable(new DefaultTableModel(data, kolom));
        JScrollPane scrollPane = new JScrollPane(table);
        add(scrollPane, BorderLayout.CENTER);
    }
}
